
Ultra Paddles - Full Project

How to Run on Replit:
1. Create a new Node.js Repl.
2. Upload these files (keep public/ folder intact).
3. Add JWT_SECRET in Replit Secrets.
4. Run "npm install" then "npm start".
5. Game will be live on your Replit URL.

public/ folder contains the client game.
