
const socket = io();
console.log("Ultra Paddles client loaded.");
